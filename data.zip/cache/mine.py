import arcade
#set size of the window and its title
screen_width , screen_height = 800,800
screen_title = 'ROG'
#scale constants
TILE_SCALING = 0.5
CHARACTER_SCALING = TILE_SCALING * 2
COIN_SCALING = TILE_SCALING
SPRITE_PIXEL_SIZE = 128
GRID_PIXEL_SIZE = SPRITE_PIXEL_SIZE * TILE_SCALING
#movement propertires
player_movementspeed = 5
player_initial_x = SPRITE_PIXEL_SIZE*TILE_SCALING*2
player_initial_y = SPRITE_PIXEL_SIZE*TILE_SCALING*1
#layer names from tiled app and direction of player 
RIGHT_FACING = 0
LEFT_FACING = 1

LAYER_NAME_PLATFORMS = "platforms"
LAYER_NAME_COINS = "coins"
LAYER_NAME_BACKGROUND = "Background"
LAYER_NAME_PLAYER = "player"

def load_texture(name) :
    return [ arcade.load_texture(name),
    arcade.load_texture(name,flipped_horizontally=True)] #left animations
class game(arcade.Window) :
    def __init__(self) :
        super().__init__()
        self.face_direction = RIGHT_FACING
        self.standing = False
        self.walking = False
        self.standing = False
        self.tile_map = None
        self.
