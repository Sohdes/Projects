import arcade

screen_width = 800
screen_Height = 800
screen_title = 'happyface'
arcade.open_window(screen_width,screen_Height,screen_title)
arcade.set_background_color(arcade.color.WENGE)
arcade.start_render()
x = 300
y = 400
arcade.draw_circle_filled(x,y,200,arcade.color.YELLOW)
x = 370
y = 350
arcade.draw_circle_filled(x,y,50,arcade.color.BLACK)
arcade.finish_render()
arcade.run()